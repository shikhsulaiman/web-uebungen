<?php

function test()
{
  for ($x = 0; $x <= 10; $x++) {
    var_dump("generator: " . $x);
    yield $x * 2 => $x;
  }
}

foreach (test() AS $key => $value) {
  var_dump("foreach: " . $key . ": " . $value);
}

 ?>
