<?php

declare(strict_types=1);

function add(int|float $a, int|float $b): int|float {
    return $a + $b;
}

var_dump(add(4.7, 5.3));