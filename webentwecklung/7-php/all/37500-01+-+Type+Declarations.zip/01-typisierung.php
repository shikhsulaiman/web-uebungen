<?php
/*
function add($a, $b) {
    var_dump($a + $b);
}

add("hallo", 9);
*/

function add(int $a, int $b) {
    //
    //
    //
    //
    var_dump($a + $b);
    //
    //
    //
}

// add("hallo", 9);
add(4, 5);