<?php

echo date("d.m.Y H:i:s", time() + (60 * 60 * 24));

 ?>
