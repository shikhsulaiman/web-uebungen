<?php

$geburtstag = "01.01.1900";

$str = "asasdfasdfasf-asdfasdfasdf-asdfadsf";
var_dump(explode("-", $str));

$alter = "?";

echo $alter;

 ?>
