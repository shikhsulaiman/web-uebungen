<?php
setlocale(LC_TIME, "de_DE", "de_DE.utf-8", "deu", "german");
echo strftime("%A, %d. %B %Y", time());
 ?>
