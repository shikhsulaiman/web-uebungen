<?php

declare(strict_types=1);

function returnStringOrNull(?int $a): ?string {
    if ($a === 5) {
        return null;
    }
    else {
        return "Hallo Welt";
    }
}

var_dump(returnStringOrNull(5));