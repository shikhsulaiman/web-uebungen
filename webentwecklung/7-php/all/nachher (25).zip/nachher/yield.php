<?php

function prim()
{
  $prim = [2];

  $x = 3;
  while(true) {
    $isPrim = true;
    foreach($prim AS $y) {
      if ($x % $y == 0) {
        $isPrim = false;
        break;
      }
    }
    if ($isPrim) {
      yield $x;
    }
    $prim[] = $x;
    $x = $x + 1;
  }
}

$prim = prim();

$counter = 0;
foreach ($prim AS $value) {
  $counter = $counter + 1;
  if ($counter >= 100) {
    break;
  }
  var_dump($value);
}
 ?>
