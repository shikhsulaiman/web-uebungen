<?php

interface AbstractExercise
{

  public function printHallo();
}


class A implements AbstractExercise
{

  public function printHallo()
  {
    var_dump("printHallo()!");
  }
}

$a = new A();
$a->printHallo();

 ?>
