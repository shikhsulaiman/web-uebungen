<?php

abstract class AbstractExercise
{

  abstract public function printHallo();
}


class A extends AbstractExercise
{

  public function printHallo()
  {
    var_dump("printHallo()!");
  }
}

$a = new A();
$a->printHallo();

 ?>
