<?php

declare(strict_types=1);

/*
function add(int $a, int $b) {
    var_dump($a + $b);
}

add((int) 4.9, 5);
*/

function add(int $a, int $b): int {
    return $a + $b;
}

var_dump(add(4, 5));