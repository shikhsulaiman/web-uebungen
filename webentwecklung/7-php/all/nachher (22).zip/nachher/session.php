<?php

session_start();

var_dump(session_save_path());

// $_SESSION["name"] = "Max";
print_r($_SESSION);

print_r($_COOKIE);

?>
