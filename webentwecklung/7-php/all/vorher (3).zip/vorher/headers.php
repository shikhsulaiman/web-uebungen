<?php

// readfile("headers.txt");
readfile("testbild.jpg");

 ?>
