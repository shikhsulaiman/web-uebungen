<?php

$time = mktime(17, 35, 0, 11, 1, 2000);
echo (time() - $time) / (60 * 60 * 24 * 365);

 ?>
