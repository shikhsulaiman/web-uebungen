<?php
$pdo = new PDO(
  'mysql:host=localhost;dbname=blog;charset=utf8',
  'blog',
  'TX4LQBEzfZfVqnLV'
);
$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

?>
