<?php

$hash = password_hash("test", PASSWORD_DEFAULT);

var_dump($hash);
var_dump(password_verify("test123", $hash));
 ?>
