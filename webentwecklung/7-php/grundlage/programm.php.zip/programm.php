<?php


$obst = "Ananas";

$warenkorb = array(
	"Banane",
	"Birne",
	"Banane",
	$obst
);

var_dump($warenkorb);

?>